document.addEventListener('DOMContentLoaded', () => {
    // --- ICON SVGs ---
    const phoneIcon = `<svg viewBox="0 0 24 24"><path d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z"/></svg>`;
    const emailIcon = `<svg viewBox="0 0 24 24"><path d="M20,8L12,13L4,8V6L12,11L20,6M20,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V6C22,4.89 21.1,4 20,4Z"/></svg>`;
    const webIcon = `<svg viewBox="0 0 24 24"><path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,19.93C7.05,19.44 4,16.08 4,12C4,11.38 4.08,10.78 4.21,10.21L9,15V16A2,2 0 0,0 11,18V19.93M13,19.93V18A2,2 0 0,0 15,16V15L19.79,10.21C19.92,10.78 20,11.38 20,12C20,16.08 16.95,19.44 13,19.93M13,4.07V6A2,2 0 0,0 11,8V9L6.21,13.79C6.08,13.22 6,12.62 6,12A6,6 0 0,1 12,6A6,6 0 0,1 18,12C18,12.62 17.92,13.22 17.79,13.79L13,9V8A2,2 0 0,0 11,6V4.07A8,8 0 0,1 12,4A8,8 0 0,1 13,4.07Z"/></svg>`;

    let profilePicUrl = 'https://via.placeholder.com/120'; // Default placeholder

    // --- SETUP EVENT LISTENERS ---
    const form = document.getElementById('resume-form');
    form.addEventListener('input', generatePreview);

    const imageInput = document.getElementById('profile-image');
    imageInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            profilePicUrl = URL.createObjectURL(file);
        }
        generatePreview();
    });

    // --- DYNAMIC FIELD FUNCTIONS ---
    window.addEducation = () => createDynamicField('education-list', educationFieldHTML);
    window.addExperience = () => createDynamicField('experience-list', experienceFieldHTML);
    window.addSkill = () => createDynamicField('skills-list', skillFieldHTML);
    window.addReference = () => createDynamicField('references-list', referenceFieldHTML);

    function createDynamicField(listId, htmlContent) {
        const list = document.getElementById(listId);
        const item = document.createElement('div');
        item.classList.add('list-item');
        item.innerHTML = htmlContent;
        list.appendChild(item);
        item.querySelector('.remove-btn').addEventListener('click', () => {
            item.remove();
            generatePreview();
        });
        generatePreview();
    }
    
    // --- HTML TEMPLATES FOR DYNAMIC FIELDS ---
    const removeButtonHTML = `<button type="button" class="remove-btn">×</button>`;
    const educationFieldHTML = `
        ${removeButtonHTML}
        <input type="text" class="dates" placeholder="e.g., 2020 - 2023">
        <input type="text" class="location" placeholder="e.g., Wardiere University">
        <input type="text" class="title" placeholder="e.g., Master of IT Management">
        <textarea class="description" placeholder="Description (optional)..."></textarea>
    `;
    const experienceFieldHTML = `
        ${removeButtonHTML}
        <input type="text" class="dates" placeholder="e.g., 2020 - 2023">
        <input type="text" class="location" placeholder="e.g., Wardiere Company">
        <input type="text" class="title" placeholder="e.g., Web Designer">
        <textarea class="description" placeholder="Describe your role and achievements..."></textarea>
    `;
    const skillFieldHTML = `
        ${removeButtonHTML}
        <input type="text" class="skill" placeholder="e.g., Web Design Tools">
    `;
    const referenceFieldHTML = `
        ${removeButtonHTML}
        <input type="text" class="ref-name" placeholder="Reference's Name">
        <input type="text" class="ref-title" placeholder="Title, Company">
        <input type="text" class="ref-contact" placeholder="Phone or Email">
    `;

    // --- PREVIEW GENERATION ---
    function generatePreview() {
        const preview = document.getElementById('resume-preview');

        // Get values
        const name = document.getElementById('name').value;
        const title = document.getElementById('title').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const website = document.getElementById('website').value;
        const about = document.getElementById('about').value.replace(/\n/g, '<br>');

        // Generate sections HTML
        const educationHtml = generateSectionHtml('#education-list', createEntryHtml);
        const experienceHtml = generateSectionHtml('#experience-list', createEntryHtml);
        const skillsHtml = generateSkillsHtml();
        const referencesHtml = generateReferencesHtml();

        // Construct final HTML
        preview.innerHTML = `
            <div class="resume-header">
                <img src="${profilePicUrl}" id="profile-pic" alt="Profile Picture">
                <div class="header-text">
                    <h1>${name || 'Your Name'}</h1>
                    <p>${title || 'Job Title'}</p>
                    <div class="contact-info">
                        ${phone ? `<div class="contact-item">${phoneIcon}<span>${phone}</span></div>` : ''}
                        ${email ? `<div class="contact-item">${emailIcon}<span>${email}</span></div>` : ''}
                        ${website ? `<div class="contact-item">${webIcon}<span>${website}</span></div>` : ''}
                    </div>
                </div>
            </div>

            ${about ? `
            <div class="resume-section">
                <h2>About Me</h2>
                <p>${about}</p>
            </div>` : ''}

            ${educationHtml ? `
            <div class="resume-section">
                <h2>Education</h2>
                ${educationHtml}
            </div>` : ''}
            
            ${experienceHtml ? `
            <div class="resume-section">
                <h2>Experience</h2>
                ${experienceHtml}
            </div>` : ''}

            ${skillsHtml ? `
            <div class="resume-section">
                <h2>Skills</h2>
                <ul class="skills-list">${skillsHtml}</ul>
            </div>` : ''}
            
            ${referencesHtml ? `
            <div class="resume-section">
                <h2>References</h2>
                <div class="references-grid">${referencesHtml}</div>
            </div>` : ''}
        `;
    }

    function generateSectionHtml(listSelector, itemHtmlGenerator) {
        let html = '';
        document.querySelectorAll(`${listSelector} .list-item`).forEach(item => {
            const data = {};
            item.querySelectorAll('input, textarea').forEach(input => {
                data[input.className] = input.value;
            });
            if (data.title && data.location) { // Only render if key fields are filled
                html += itemHtmlGenerator(data);
            }
        });
        return html;
    }

    function createEntryHtml(data) {
        return `
            <div class="entry">
                <div class="entry-left">
                    <p class="dates">${data.dates || ''}</p>
                    <p class="location">${data.location || ''}</p>
                </div>
                <div class="entry-right">
                    <h3>${data.title || ''}</h3>
                    <p>${data.description ? data.description.replace(/\n/g, '<br>') : ''}</p>
                </div>
            </div>
        `;
    }

    function generateSkillsHtml() {
        let html = '';
        document.querySelectorAll('#skills-list .skill').forEach(input => {
            if (input.value) {
                html += `<li>${input.value}</li>`;
            }
        });
        return html;
    }

    function generateReferencesHtml() {
        let html = '';
        document.querySelectorAll('#references-list .list-item').forEach(item => {
            const name = item.querySelector('.ref-name').value;
            const title = item.querySelector('.ref-title').value;
            const contact = item.querySelector('.ref-contact').value;
            if (name) {
                html += `
                    <div class="reference-item">
                        <p class="ref-name">${name}</p>
                        <p class="ref-title">${title}</p>
                        <p class="ref-contact"><strong>Contact:</strong> ${contact}</p>
                    </div>`;
            }
        });
        return html;
    }

    // Initialize with some empty fields for a better user experience
    addExperience();
    addEducation();
    addSkill();
    addSkill();
    addSkill();
    addSkill();
    addReference();
    generatePreview();
});